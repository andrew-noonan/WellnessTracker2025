# Entry point of the application
from helperClasses import Variable
from helperClasses import Question, CheckboxQuestion
from helperFuncs import *

def main():
    # Import all questions and get list all_questions
    config_filepath = r'C:\Users\anoon\Desktop\Code Dev\DynamicLicenseGenerator\templates\config1.xlsx'
    template_filepath = r'C:\Users\anoon\Desktop\Code Dev\DynamicLicenseGenerator\templates\template1.docx'
    output_directory = r'C:\Users\anoon\Desktop\Code Dev\DynamicLicenseGenerator\outputs'
    all_questions = importQuestions(config_filepath)
    questions_dict = {}

    # Print all questions for verification and create dictionary with QID as key
    for question in all_questions:
        print(question)
        questions_dict[question.question_id] = question

    print()
    # Testing condition checking logic
    if questions_dict["CH1"].conditionsSatisfied:
        print("CH1 conditions satisfied")
    else:
        print("CH1 conditions NOT satisfied")

    print("Updating YN1")
    questions_dict["YN1"].values.extend("Y")
    check_question_conditions(questions_dict["CH1"], questions_dict)


    if questions_dict["CH1"].conditionsSatisfied:
        print("CH1 conditions satisfied")
    else:
        print("CH1 conditions NOT satisfied")

    variables = import_vars_from_template(template_filepath)

    # Printing variable names and their details
    for var_name, occurrences in variables.items():
        print(f"Variable: {var_name}")
        for occurrence in occurrences:
            print(f" - Found in text: {occurrence['text'][occurrence['start']:occurrence['end']]}")

    # Replacing Static Variables
    static_vars = load_static_variables(config_filepath)
    replace_and_highlight(template_filepath, static_vars, output_directory)
    

if __name__ == "__main__":
    main()
