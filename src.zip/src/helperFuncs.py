# helperFuncs.py

import openpyxl
from docx import Document
from docx.shared import RGBColor
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from helperClasses import Question, CheckboxQuestion

# HELPER FUNCTIONS FOR READING IN QUESTIONS
def parse_conditions(*conditions):
    conditions_list = []
    for condition in conditions:
        if condition:
            conditions_list.append([c.strip() for c in condition.split(',')])
        else:
            conditions_list.append([])
    return conditions_list

def read_sheet(ws, question_class, has_options=False):
    questions = []
    for row in ws.iter_rows(min_row=2, values_only=True):  # Skipping the header row
        question_id, prompt, cond1, cond2, cond3, *_ = row
        question_type = question_id[:2]
        if has_options:
            options = [option.strip() for option in row[5].split(',')] if row[5] else []
            question = CheckboxQuestion(question_id, question_type, cond1, cond2, cond3, prompt, options)
        else:
            question = Question(question_id, question_type, cond1, cond2, cond3, prompt)
        questions.append(question)
    return questions


def importQuestions(filepath):
    workbook = openpyxl.load_workbook(filepath)
    
    # Create a single list to hold all questions
    all_questions = []

    # Read questions from each sheet and extend the all_questions list
    all_questions.extend(read_sheet(workbook['CheckboxQuestions'], CheckboxQuestion, has_options=True))
    all_questions.extend(read_sheet(workbook['YesNoQuestions'], Question))
    all_questions.extend(read_sheet(workbook['Free Response'], Question))
    
    return all_questions

# Example usage
# all_questions = importQuestions('path_to_your_excel_file.xlsx')

# HELPER FUNCTIONS FOR CONDITION EVALUATION
def evaluate_condition(subcondition, questions_dict):
    """Evaluate a single subcondition against the provided dictionary of questions."""
    identifier, expected = subcondition
    question = questions_dict.get(identifier)
    
    # If the question doesn't exist or its values haven't been determined, return False
    if not question or not question.values:
        return False
    
    # Check if the expected value matches the question's current value(s)
    if expected.startswith('!'):
        # Expected value should not be in the question's values
        return expected[1:] not in question.values
    else:
        # Expected value should be in the question's values
        return expected in question.values

def check_question_conditions(question, questions_dict):
    """Updates the conditionsSatisfied attribute for the provided question."""
    condition_satisfied = False  # Default to False until proven otherwise
    
    # Evaluate non-empty conditions
    conditions = [question.conditions1, question.conditions2, question.conditions3]
    for condition in conditions:
        # Skip empty conditions
        if not condition:
            continue
        
        # Assume the condition is satisfied until proven otherwise
        condition_satisfied = True
        for subcondition in condition:
            if not evaluate_condition(subcondition, questions_dict):
                condition_satisfied = False
                break  # If any subcondition is not satisfied, the entire condition fails

        # If any condition set is satisfied, set conditionsSatisfied to True and exit
        if condition_satisfied:
            break

    # Update the question's conditionsSatisfied attribute
    question.conditionsSatisfied = condition_satisfied

# HELPER FUNCTIONS FOR READING AND WRITING WORD DOC
from docx import Document

from docx import Document

def import_vars_from_template(filepath):
    doc = Document(filepath)
    variables = {}

    for paragraph in doc.paragraphs:
        full_text = "".join(run.text for run in paragraph.runs)
        
        start = full_text.find('{{')
        end = full_text.find('}}', start + 2)

        while start != -1 and end != -1 and start < end:
            var_name = full_text[start + 2:end]
            if var_name not in variables:
                variables[var_name] = []

            variables[var_name].append({'text': full_text, 'start': start, 'end': end + 2})
            start = full_text.find('{{', end + 2)
            end = full_text.find('}}', start + 2)

    return variables

def load_static_variables(excel_path):
    workbook = openpyxl.load_workbook(excel_path)
    sheet = workbook['StaticVariables']
    static_vars = {row[0]: row[1] for row in sheet.iter_rows(min_row=2, values_only=True)}
    return static_vars

def highlight_run(run, color):
    """Applies background color to a run."""
    shd = OxmlElement('w:shd')
    shd.set(qn('w:fill'), color)
    run._element.append(shd)

def replace_and_highlight(doc_path, static_vars, output_directory):
    doc = Document(doc_path)
    
    for paragraph in doc.paragraphs:
        for run in paragraph.runs:
            new_runs = []
            text = run.text
            
            # Check and replace variables in the run text
            for var_name, var_value in static_vars.items():
                placeholder = f"{{{{{var_name}}}}}"
                if placeholder in text:
                    # Split the text around the variable
                    before, match, after = text.partition(placeholder)
                    # Add text before the variable, if any
                    if before:
                        new_runs.append((before, None))
                    # Add the variable replacement and mark it for yellow highlight
                    new_runs.append((var_value, "FFFF00"))
                    # Remaining text becomes the new text to process in the next iteration
                    text = after
            
            # If there are remaining placeholders in the final text
            if "{{" in text and "}}" in text:
                # Split the text around the first remaining placeholder
                before, variable, after = text.partition("{{")
                _, variable, after = after.partition("}}")
                # Add text before the variable, if any
                if before:
                    new_runs.append((before, None))
                # Add the unchanged variable and mark it for orange highlight
                new_runs.append((f"{{{{{variable}}}}}", "FFA500"))
                # Add remaining text after the variable, if any
                if after:
                    new_runs.append((after, None))
            elif text:  # No more placeholders, just add remaining text
                new_runs.append((text, None))
                
            # Clear the original run text and apply new text with appropriate highlighting
            run.text = ''
            for text_part, color in new_runs:
                new_run = paragraph.add_run(text_part)
                if color:
                    highlight_run(new_run, color)
                    
    output_filename = doc_path.split('\\')[-1].replace('.docx', '_generated.docx')
    doc.save(output_filename)
