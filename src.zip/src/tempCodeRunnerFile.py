 # if check_conditions(all_questions[0]):
    #     print("CH1 conditions satisfied")
    # else:
    #     print("CH1 conditions NOT satisfied")

    # print("Updating YN1")
    # all_questions[1].values[0] = "Y"

    # if check_conditions(all_questions[0]):
    #     print("CH1 conditions satisfied")
    # else:
    #     print("CH1 conditions NOT satisfied")
    